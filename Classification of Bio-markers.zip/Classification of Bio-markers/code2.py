# -*- coding: utf-8 -*-
"""
Created on Thu Dec 13 22:06:24 2018

@author: anish
"""

from sklearn import svm
from sklearn import metrics
import pandas as pd
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import VarianceThreshold
from sklearn.feature_selection import f_classif
import matplotlib.pyplot as plt
import numpy as np
########################################################################################################################
########################################################################################################################

# Loading the data
data = pd.read_csv('D:\ANISH\MSc\PR\Project\\testing2.csv')


# Transposing the data
data_transpose = data.T


# This takes all the columns except the last and all the values of the row in those columns
x = data_transpose.iloc [:, :60483 ].values

# This takes the last column and all the values of the row in the last last column
y = data_transpose.iloc[:,-1].values

########################################################################################################################
########################################################################################################################

def trainAndTest(model, x, y):
    model.fit(x, y)
    b_pred=model.predict(x)
    acc = metrics.accuracy_score(y, b_pred)
    return acc

# Uncomment the following lines to know the accuracy of the dataset before feature selection

'''
model_svm = svm.LinearSVC()
acc = trainAndTest(model_svm, x, y)

print("Initial Accuracy: {0}".format(acc))
'''
########################################################################################################################
########################################################################################################################

# Data Preprocessing

p=0.1
sel = VarianceThreshold(threshold=(p * (1 - p)))
x2 = sel.fit_transform(x)


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
scaler.fit(x2) 
xs = scaler.transform(x2)



########################################################################################################################
########################################################################################################################

accs = []
for i in range(1,22606,200):
    x_new = SelectKBest(f_classif, k=i).fit_transform(xs, y)
    model = svm.LinearSVC()
    # For using Naive Bayes use model = GaussianNB()
    acc = trainAndTest(model, x_new, y)
    print("i: {0}, Accuracy: {1}".format(i,acc))
    accs.append(acc)

xaxis = [i for i in range(1,17002,200)]
plt.plot(xaxis, accs)
plt.show()